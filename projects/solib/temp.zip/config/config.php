<?php

ini_set("default-charset", "UTF-8");


define('dbhost', 'localhost');
define('dbuser', 'root');
define('dbpass', '');
define('dbname', 'solib');


define('glob_site_name', 'Solace Library');
define('glob_site_url', 'http://localhost/solib');






